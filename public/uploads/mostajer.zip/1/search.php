<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// داده‌های نمونه محصولات
$products = [
    [
        'id' => 1,
        'name' => 'لپ تاپ اپل مک‌بوک پرو',
        'category' => 'لپ تاپ',
        'price' => '85,000,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=150&h=150&fit=crop'
    ],
    [
        'id' => 2,
        'name' => 'گوشی سامسونگ گلکسی S24',
        'category' => 'گوشی موبایل',
        'price' => '45,000,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=150&h=150&fit=crop'
    ],
    [
        'id' => 3,
        'name' => 'هدفون سونی WH-1000XM5',
        'category' => 'هدفون',
        'price' => '12,500,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=150&h=150&fit=crop'
    ],
    [
        'id' => 4,
        'name' => 'ساعت هوشمند اپل واچ',
        'category' => 'ساعت هوشمند',
        'price' => '18,000,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=150&h=150&fit=crop'
    ],
    [
        'id' => 5,
        'name' => 'تبلت آیپد پرو',
        'category' => 'تبلت',
        'price' => '32,000,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=150&h=150&fit=crop'
    ],
    [
        'id' => 6,
        'name' => 'دوربین کانن EOS R5',
        'category' => 'دوربین',
        'price' => '95,000,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=150&h=150&fit=crop'
    ],
    [
        'id' => 7,
        'name' => 'کنسول بازی پلی استیشن 5',
        'category' => 'کنسول بازی',
        'price' => '28,000,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=150&h=150&fit=crop'
    ],
    [
        'id' => 8,
        'name' => 'اسپیکر بلوتوث JBL',
        'category' => 'اسپیکر',
        'price' => '3,500,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=150&h=150&fit=crop'
    ],
    [
        'id' => 9,
        'name' => 'کیبورد مکانیکال Razer',
        'category' => 'کیبورد',
        'price' => '8,500,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=150&h=150&fit=crop'
    ],
    [
        'id' => 10,
        'name' => 'ماوس گیمینگ Logitech',
        'category' => 'ماوس',
        'price' => '2,800,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=150&h=150&fit=crop'
    ],
    [
        'id' => 11,
        'name' => 'مانیتور سامسونگ 32 اینچ',
        'category' => 'مانیتور',
        'price' => '15,000,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=150&h=150&fit=crop'
    ],
    [
        'id' => 12,
        'name' => 'پاوربانک Anker',
        'category' => 'پاوربانک',
        'price' => '1,200,000 تومان',
        'image' => 'https://images.unsplash.com/photo-1609592806598-04c4d7e5c1a8?w=150&h=150&fit=crop'
    ]
];

// دریافت کوئری جستجو
$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$query = isset($_POST['q']) ? trim($_POST['q']) : $query;

// اگر کوئری خالی باشد، همه محصولات را برگردان
if (empty($query)) {
    echo json_encode([
        'success' => true,
        'count' => count($products),
        'results' => $products
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// جستجو در محصولات
$results = [];
$query_lower = mb_strtolower($query, 'UTF-8');

foreach ($products as $product) {
    $name_lower = mb_strtolower($product['name'], 'UTF-8');
    $category_lower = mb_strtolower($product['category'], 'UTF-8');
    
    if (mb_strpos($name_lower, $query_lower) !== false || 
        mb_strpos($category_lower, $query_lower) !== false) {
        $results[] = $product;
    }
}

// پاسخ JSON
echo json_encode([
    'success' => true,
    'query' => $query,
    'count' => count($results),
    'results' => $results
], JSON_UNESCAPED_UNICODE);
?> 