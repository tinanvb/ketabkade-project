import mongoose from "mongoose";
const DiscountSchema = new mongoose.Schema(
  {
    discountCode: {
      type: String,
      required: true,
      trim: true,
    },
    discountPercentage: {
      type: Number,
      required: true,
    },
    date: {
      type: Date,
      required: true,
    },
    isActive: {
      type: Boolean,
      required: true,
    },
  },
  { timestamps: true }
);
export default mongoose.models.Discount ||
  mongoose.model("Discount", DiscountSchema);
