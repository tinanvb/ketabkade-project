import mongoose from "mongoose";

const ProductCommentSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: true,
      trim: true,
    },
    lastName: {
      type: String,
      required: true,
      trim: true,
    },
    comment: {
      type: String,
      required: true,
      trim: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Product",
      required: true,
    },
    isApproved: {
      type: Boolean,
      default: false,
    },
    date: {
      type: Date,
      default: Date.now
    },  
  },
  { timestamps: true }
);

export default mongoose.models.ProductComment ||
  mongoose.model("ProductComment", ProductCommentSchema);
