import mongoose from "mongoose";

const SlideshowSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      trim: true,
    },
    imageUrl: {
      type: String,
      required: true,
      trim: true,
    },
    link: {
        type: String,
        required: true,
        trim: true,
      },
  },
  { timestamps: true }
);

export default mongoose.models.Slideshow || mongoose.model("Slideshow", SlideshowSchema);
