import mongoose from "mongoose";

const AdsSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      trim: true,
    },
    imageUrl: {
      type: String,
      required: true,
      trim: true,
    },
    link: {
        type: String,
        required: true,
        trim: true,
      },
  },
  { timestamps: true }
);

export default mongoose.models.Ads || mongoose.model("Ads", AdsSchema);
