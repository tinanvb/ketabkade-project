"use client";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import React, { useEffect } from "react";

export default function AuthWrapper({ children }) {
  const { data: session, status } = useSession();
  const router = useRouter();
  useEffect(() => {
    console.log("AuthWrapper rendered", { status, session });

    if (status === "unauthenticated") {
      router.push("/auth/login");
    } else if (status === "authenticated" && !session?.user?.isAdmin) {
      router.push("/auth/login");
    }
  }, [status, session, router]);

  if (status === "loading") {
    return <div>در حال بارگذاری...</div>;
  }
  if (status === "authenticated" && session?.user?.isAdmin) {
    return <>{children}</>;
  }
  return null;
}
