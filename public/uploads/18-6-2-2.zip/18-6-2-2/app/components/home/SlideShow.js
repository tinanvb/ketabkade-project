"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import { getSlide } from "@/app/home/lib/getSlide";


const SlideShow = () => {
  const [slides, setSlides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSlides = async () => {
      try {
        const data = await getSlide();
        if (!Array.isArray(data)) {
          throw new Error("داده‌های اسلایدشو معتبر نیستند");
        }
        setSlides(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchSlides();
  }, []);

  useEffect(() => {
    if (slides.length > 0) {
      $(".slide-owl-carousel").owlCarousel({
        items: 1,
        loop: true,
        autoplay: true,
        rtl: true,
        nav: true,
        dots: true,
      });
    }
  }, [slides]);

  if (loading) return <div>در حال بارگذاری اسلایدشو...</div>;
  if (error) return <div>خطا در بارگذاری: {error}</div>;

  return (
    <section className="row">
      <section className="col-md-8 pe-md-1">
        <section id="slideshow" className="owl-carousel slide-owl-carousel owl-theme">
          {slides.map((slide) => (
            <section key={slide._id} className="item">
              <a className="w-100 d-block h-auto text-decoration-none" href={slide.link || "#"}>
                <Image
                  src={slide.imageUrl}
                  alt={slide.name || "اسلاید بدون نام"}
                  width={800}
                  height={400}
                  className="w-100 rounded-2"
                />
              </a>
            </section>
          ))}
        </section>
      </section>
      <section className="col-md-4 ps-md-1 mt-2 mt-md-0">
        <section className="mb-2">
          <a href="#" className="d-block">
            <Image
              src="/images/slideshow/12.gif"
              alt="تبلیغ 1"
              width={400}
              height={200}
              className="w-100 rounded-2"
            />
          </a>
        </section>
        <section className="mb-2">
          <a href="#" className="d-block">
            <Image
              src="/images/slideshow/11.jpg"
              alt="تبلیغ 2"
              width={400}
              height={200}
              className="w-100 rounded-2"
            />
          </a>
        </section>
      </section>
    </section>
  );
};

export default SlideShow;
