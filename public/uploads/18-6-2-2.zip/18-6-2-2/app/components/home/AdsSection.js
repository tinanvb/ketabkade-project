"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import { getAds } from "@/app/home/lib/getAds";

const AdsSection = () => {
  const [ads, setAds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAds = async () => {
      try {
        const data = await getAds();
        if (!Array.isArray(data)) {
          throw new Error("داده‌های تبلیغات معتبر نیستند");
        }
        setAds(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAds();
  }, []);

  useEffect(() => {
    if (ads.length > 0) {
      $(".ads-owl-carousel").owlCarousel({
        items: 2,
        loop: true,
        rtl: true,
        responsive: {
          0: { items: 2 },
          576: { items: 2 },
          768: { items: 2 },
          992: { items: 2 },
        },
      });
    }
  }, [ads]);

  if (loading) return <div>در حال بارگذاری تبلیغات...</div>;
  if (error) return <div>خطا در بارگذاری تبلیغات: {error}</div>;

  return (
    <section className="mb-3">
      <section className="container-xxl">
        <section className="row">
          <section className="col">
            <section className="content-wrapper bg-white p-3 rounded-2">
              <h2 className="content-header-title">
                <span>تبلیغات ویژه</span>
              </h2>
              <section className="lazyload-wrapper">
                <section className="lazyload light-owl-nav ads-owl-carousel owl-carousel owl-theme ">
                  {ads.map((ad) => (
                    <section
                      key={ad._id}
                      className="col-12 p-2 mt-md-0  text-center"
                    >
                      <a
                        href={ad.link}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Image
                          src={ad.imageUrl}
                          alt={ad.name || "بدون نام"}
                          width={300}
                          height={200}
                          className="rounded-2"
                        />
                      </a>
                      <p>{ad.name}</p>
                    </section>
                  ))}
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    </section>
  );
};

export default AdsSection;
