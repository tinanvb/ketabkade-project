"use client";

import { useSession } from "next-auth/react";
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import { Modal, Button, Spinner } from "react-bootstrap";
import "@/app/styles/product.css";
import DateObject from "react-date-object";
import persian from "react-date-object/calendars/persian";
import persian_fa from "react-date-object/locales/persian_fa";
import { getComments } from "@/app/home/lib/getComments";

const ProductComments = ({ productId }) => {
  const { data: session, status } = useSession();
  const [comment, setComment] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [comments, setComments] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const fetchComments = async () => {
      try {
        const data = await getComments(productId);
        setComments(data);
      } catch (error) {
        setError(error.message);
        alert(error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchComments();
  }, [productId]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!firstName || !lastName || !comment) {
      const errorMessage = "لطفاً همه فیلدها را پر کنید.";
      setError(errorMessage);
      alert(errorMessage);
      return;
    }

    if (firstName.length < 3 || firstName.length > 30) {
      const errorMessage = "نام باید بین ۳ تا ۳۰ کاراکتر باشد";
      setError(errorMessage);
      alert(errorMessage);
      return;
    }

    if (lastName.length < 3 || lastName.length > 30) {
      const errorMessage = "نام خانوادگی باید بین ۳ تا ۳۰ کاراکتر باشد";
      setError(errorMessage);
      alert(errorMessage);
      return;
    }

    if (comment.length < 3 || comment.length > 300) {
      const errorMessage = "کامنت باید بین ۳ تا ۳۰۰ کاراکتر باشد";
      setError(errorMessage);
      alert(errorMessage);
      return;
    }

    try {
      const response = await fetch("/api/productComments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          firstName,
          lastName,
          comment,
          userId: session?.user?.id,
          productId,
          createdAt: new Date().toISOString(),
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setComments((prev) => [data, ...prev]);
        setComment("");
        setFirstName("");
        setLastName("");
        setShowModal(false);
        alert("نظر شما با موفقیت ثبت شد.");
      } else {
        setError(data.message || "مشکلی در ثبت دیدگاه پیش آمد.");
        alert(data.message || "مشکلی در ثبت دیدگاه پیش آمد.");
      }
    } catch (error) {
      setError("خطایی رخ داده است.");
      alert("خطایی رخ داده است.");
    }
  };

  return (
    <>
      <section id="comments" className="content-header mt-2 mb-4">
        <section className="d-flex justify-content-between align-items-center">
          <h2 className="content-header-title content-header-title-small">
            دیدگاه ها
          </h2>
        </section>
      </section>

      <section className="product-comments mb-4">
        {status === "authenticated" ? (
          <>
            <button
              className="comment-add-button"
              type="button"
              onClick={() => setShowModal(true)}
            >
              <i className="fa fa-plus"></i> افزودن دیدگاه
            </button>

            <Modal show={showModal} onHide={() => setShowModal(false)}>
              <Modal.Header closeButton>
                <Modal.Title>افزودن دیدگاه</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <form onSubmit={handleSubmit}>
                  <div className="row">
                    <div className="col-6 mb-2">
                      <label htmlFor="firstName" className="form-label mb-1">
                        نام
                      </label>
                      <input
                        type="text"
                        className="form-control form-control-sm"
                        id="firstName"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        placeholder="نام ..."
                        required
                      />
                    </div>
                    <div className="col-6 mb-2">
                      <label htmlFor="lastName" className="form-label mb-1">
                        نام خانوادگی
                      </label>
                      <input
                        type="text"
                        className="form-control form-control-sm"
                        id="lastName"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        placeholder="نام خانوادگی ..."
                        required
                      />
                    </div>
                  </div>

                  <div className="col-12 mb-2">
                    <label htmlFor="comment" className="form-label mb-1">
                      دیدگاه شما
                    </label>
                    <textarea
                      className="form-control form-control-sm"
                      id="comment"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="دیدگاه شما ..."
                      rows="4"
                      required
                    ></textarea>
                  </div>

                  <div className="modal-footer">
                    <Button type="submit" variant="primary">
                      ثبت دیدگاه
                    </Button>
                    <Button
                      variant="danger"
                      onClick={() => setShowModal(false)}
                    >
                      بستن
                    </Button>
                  </div>
                </form>
              </Modal.Body>
            </Modal>
          </>
        ) : (
          <p className="alert alert-warning">
            برای ارسال دیدگاه باید وارد حساب کاربری خود شوید.
          </p>
        )}
        {loading ? (
          <div className="d-flex justify-content-center mt-4">
            <Spinner animation="border" variant="primary" />
          </div>
        ) : (
          <section className="product-comment-list">
            {comments.map((comment) => {
              const date = comment.createdAt
                ? new DateObject({
                    date: comment.createdAt,
                    calendar: persian,
                    locale: persian_fa,
                  }).format("DD MMMM YYYY")
                : "بدون تاریخ";

              return (
                <div className="product-comment" key={comment._id}>
                  <div className="product-comment-header d-flex justify-content-start">
                    <div className="product-comment-date">{date}</div>
                    <div className="product-comment-title">
                      {comment.firstName} {comment.lastName}
                    </div>
                  </div>
                  <div className="product-comment-body">{comment.comment}</div>
                </div>
              );
            })}
          </section>
        )}
      </section>
    </>
  );
};

export default ProductComments;
