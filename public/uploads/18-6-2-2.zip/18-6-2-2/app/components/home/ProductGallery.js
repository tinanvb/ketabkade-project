import Image from "next/image";
import React from "react";

const ProductGallery = ({ images }) => {
  const mainImage =
    Array.isArray(images) && images.length > 0 ? images[0] : images;
  return (
    <section className="content-wrapper bg-white p-3 rounded-2 mb-4">
      <section className="product-gallery">
        <section className="product-gallery-selected-image mb-3">
          <Image src={mainImage} alt="تصویر محصول" width={300} height={350} />
        </section>
        <section className="product-gallery-thumbs">

        </section>
      </section>
    </section>
  );
};

export default ProductGallery;
