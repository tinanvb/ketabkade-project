"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import { getBrands } from "@/app/home/lib/getBrands";


const BrandSection = () => {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBrands = async () => {
      try {
        const data = await getBrands();
        if (!Array.isArray(data)) {
          throw new Error("داده های دریافتی معتبر نمیباشند");
        }
        setBrands(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchBrands();
  }, []);

  useEffect(() => {
    if (brands.length > 0) {
      $(".brand-owl-carousel").owlCarousel({
        items: 4,
        loop: true,
        autoplay: true,
        rtl: true,
        responsive: {
          0: { items: 1 },
          576: { items: 2 },
          768: { items: 3 },
          992: { items: 4 },
        },
      });
    }
  }, [brands]);

  if (loading) return <div>در حال بارگذاری برندها...</div>;
  if (error) return <div>خطا در بارگذاری داده ها: {error}</div>;

  return (
    <section className="mb-3">
      <section className="container-xxl">
        <section className="row">
          <section className="col">
            <section className="content-wrapper bg-white p-3 rounded-2">
              <section className="content-header">
                <section className="d-flex justify-content-between align-items-center">
                  <h2 className="content-header-title">
                    <span>برندهای ویژه</span>
                  </h2>
                  <section className="content-header-link">
                    <a href="#">مشاهده همه</a>
                  </section>
                </section>
              </section>
              <section className="lazyload-wrapper">
                <section className="lazyload light-owl-nav brand-owl-carousel owl-carousel owl-theme">
                  {brands.map((brand) => (
                    <section key={brand._id} className="item">
                      <section className="brand-item text-center">
                        <Image
                          src={brand.imageUrl }
                          alt={brand.name}
                          width={800}
                          height={100}
                          className="rounded-2"
                        />
                        {/* <p>{brand.name}</p> */}
                      </section>
                    </section>
                  ))}
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    </section>
  );
};

export default BrandSection;
