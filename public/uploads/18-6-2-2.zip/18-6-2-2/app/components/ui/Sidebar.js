import Link from "next/link";
import React from "react";
import { Nav } from "react-bootstrap";
import { FaBox, FaComment, FaHome, FaPercent, FaStore, FaTags, FaUser } from "react-icons/fa";

const Sidebar = () => {
  return (
    <aside className="sidebar">
      <Nav className="flex-column mt-3 ">
        <Link href="/admin">
          <FaHome />
          داشبورد
        </Link>
        <Link href="/admin/categories">
          <FaTags />
           مدیریت دسته بندی ها
        </Link>
        <Link href="/admin/products">
          <FaBox />
           مدیریت محصولات
        </Link>
         <Link href="/admin/discount">
          <FaPercent />
          مدیریت کد های تخفیف
        </Link> <Link href="/admin/comments">
          <FaComment />
          مدیریت نظرات
        </Link> <Link href="/admin/stock">
          <FaStore />
          مدیریت انبار موجودی
        </Link> <Link href="/admin/users">
          <FaUser />
          مدیریت کاربران
        </Link>
      </Nav>
    </aside>
  );
};

export default Sidebar;
