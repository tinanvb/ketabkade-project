import connectToDatabase from "@/app/lib/db";
import User from "@/models/User";

export async function GET(request, { params }) {
  await connectToDatabase();
  const { id } = await params;
  try {
    const user = await User.findById(id);
    if (!user) {
      return new Response(JSON.stringify({ message: "کاربر پیدا نشد" }), {
        status: 404,
      });
    }
    return new Response(JSON.stringify(user), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}

export async function PUT(request, { params }) {
  await connectToDatabase();
  try {
    const { id } = await params;
    const body = await request.json();
    const { name ,email,isAdmin} = body;
    if (
      !name ||
      typeof name !== "string" ||
      body.name.trim() === ""
    ) {
      return new Response(
        JSON.stringify({ message: "نام کاربر الزامی میباشد" }),
        {
          status: 400,
        }
      );
    }
    if (name.length < 3) {
      return new Response(
        JSON.stringify({ message: "نام کاربر باید بزرگتر از ۳ کاراکتر باشد" }),
        {
          status: 400,
        }
      );
    }
    let{phone}=body
    if (phone) {
      phone = Number(phone);
    }
    if (!phone || typeof phone !== "number") {
      return new Response(
        JSON.stringify({ message: "موبایل کاربر الزامی میباشد" }),
        {
          status: 400,
        }
      );
    }
    if(typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return new Response(
        JSON.stringify({ message: "ایمیل معتبر نمیباشد" }),
        { status: 400 }
      );
    }
    if (typeof isAdmin !== "boolean") {
      return new Response(
        JSON.stringify({ message: "وضعیت ادمین باید مقدار صحیح یا غلط باشد" }),
        { status: 400 }
      );
    }

    const user = await User.findByIdAndUpdate(id, body, {
      new: true,
    });
    return new Response(JSON.stringify(user), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}

export async function DELETE(request, { params }) {
  await connectToDatabase();
  try {
    const { id } = await params;
    await User.findByIdAndDelete(id);
    return new Response(null, { status: 204 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
export async function PATCH(request, { params }) {
  await connectToDatabase();
  try {
    const { id } = await params;
    const { isAdmin } = await request.json();
    const user = await User.findById(id);
    if (!user) {
      return new Response(JSON.stringify({ message: "کاربر پیدا نشد" }), {
        status: 404,
      });
    }
    user.isAdmin = isAdmin;
    await user.save();
    return new Response(JSON.stringify(user), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
