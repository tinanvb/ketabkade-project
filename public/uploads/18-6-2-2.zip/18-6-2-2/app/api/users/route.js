import connectToDatabase from "@/app/lib/db";
import User from "@/models/User";

export async function GET(request) {
  await connectToDatabase();
  const users = await User.find({});
  return new Response(JSON.stringify(users), { status: 200 });
}

export async function POST(request) {
  await connectToDatabase();
  try {
    const body = await request.json();
    const { name, phone, email, isAdmin } = body;
    if (!name || typeof name !== "string" || name.trim() === "") {
      return new Response(
        JSON.stringify({ message: "نام کاربر الزامی میباشد" }),
        { status: 400 }
      );
    }
    if (name.length < 3) {
      return new Response(
        JSON.stringify({ message: "نام کاربر باید بزرگتر از ۳ کاراکتر باشد" }),
        { status: 400 }
      );
    }
    if (!phone || typeof phone !== "string" || !/^\d{11}$/.test(phone)) {
      return new Response(
        JSON.stringify({ message: "شماره موبایل باید ۱۱ رقمی و معتبر باشد" }),
        { status: 400 }
      );
    }

    // **اعتبارسنجی ایمیل (در صورتی که مقدار داشته باشد)**
    if (email && (typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) {
      return new Response(
        JSON.stringify({ message: "ایمیل معتبر نمیباشد" }),
        { status: 400 }
      );
    }
    if (typeof isAdmin !== "boolean") {
      return new Response(
        JSON.stringify({ message: "وضعیت ادمین باید مقدار صحیح یا غلط باشد" }),
        { status: 400 }
      );
    }
    const newUser = await User.create({ name, phone, email, isAdmin });

    return new Response(JSON.stringify(newUser), { status: 201 });
  } catch (error) {
    return new Response(
      JSON.stringify({ message: "خطای سرور: " + error.message }),
      { status: 500 }
    );
  }
}
