import connectToDatabase from "@/app/lib/db";
import Slideshow from "@/models/Slideshow";
import { NextResponse } from "next/server";

export async function GET() {
  await connectToDatabase();

  try {
    const slideshow = await Slideshow.find({}).limit(4).select("link imageUrl");
    console.log("Slideshow data:", slideshow); 
    return NextResponse.json(slideshow, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      {
        error: "مشکلی در دریافت اسلاید رخ داده است",
      },
      { status: 500 }
    );
  }
}
