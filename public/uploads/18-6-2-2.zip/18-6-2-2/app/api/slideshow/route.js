import connectToDatabase from "@/app/lib/db";
import { NextResponse } from "next/server";
import { join } from "path";
import { writeFile } from "fs/promises";
import Slideshow from "@/models/Slideshow";

export async function GET(request) {
  await connectToDatabase();
  const slideshow = await Slideshow.find({});
  return new Response(JSON.stringify(slideshow), { status: 200 });
}

export async function POST(request) {
  try {
    await connectToDatabase();
    const data = await request.formData();
    const name = data.get("name");
    const link = data.get("link");
    const file = data.get("image");

    if (!file) {
      return NextResponse.json(
        {
          success: false,
          message: "آپلود تصویر برند الزامی است",
        },
        { status: 400 }
      );
    }
    if (!link || !/^https?:\/\//.test(link)) {
        return NextResponse.json({ success: false, message: "لینک معتبر نیست" }, { status: 400 });
      }
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const uploadDir = join(process.cwd(), "public/images/slideshow");
    const filePath = join(uploadDir, file.name);
    await writeFile(filePath, buffer);
    const slideshow = await Slideshow.create({
      name,
      link,
      imageUrl: `images/slideshow/${file.name}`,
    });

    return NextResponse.json(slideshow, { status: 201 });
  } catch (error) {
    return NextResponse.json({ message: error.message }, { status: 500 });
  }
}
