import connectToDatabase from "@/app/lib/db";
import { NextResponse } from "next/server";
import { join } from "path";
import { writeFile } from "fs/promises";
import Ads from "@/models/Ads";

export async function GET(request) {
  await connectToDatabase();
  const ads = await Ads.find({});
  return new Response(JSON.stringify(ads), { status: 200 });
}

export async function POST(request) {
  try {
    await connectToDatabase();
    const data = await request.formData();
    const name = data.get("name");
    const link = data.get("link");
    const file = data.get("image");

    if (!name || typeof name !== "string" || name.trim().length < 3) {
      return NextResponse.json(
        {
          success: false,
          message: "نام برند الزامی است و باید حداقل ۳ کاراکتر باشد",
        },
        { status: 400 }
      );
    }

    if (!file) {
      return NextResponse.json(
        {
          success: false,
          message: "آپلود تصویر برند الزامی است",
        },
        { status: 400 }
      );
    }
    if (!link || !/^https?:\/\//.test(link)) {
        return NextResponse.json({ success: false, message: "لینک معتبر نیست" }, { status: 400 });
      }
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const uploadDir = join(process.cwd(), "public/images/ads");
    const filePath = join(uploadDir, file.name);
    await writeFile(filePath, buffer);
    const ad = await Ads.create({
      name,
      link,
      imageUrl: `images/slideshow/${file.name}`,
    });

    return NextResponse.json(ad, { status: 201 });
  } catch (error) {
    return NextResponse.json({ message: error.message }, { status: 500 });
  }
}
