import connectToDatabase from "@/app/lib/db";
import Ads from "@/models/Ads";
import { NextResponse } from "next/server";

export async function GET() {
  await connectToDatabase();

  try {
    const ads = await Ads.find({}).limit(2).select("link imageUrl");

    return NextResponse.json(ads, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      {
        error: "مشکلی در دریافت محصولات پربازدید رخ داده است",
      },
      { status: 500 }
    );
  }
}
