import connectToDatabase from "@/app/lib/db";
import { sendSms } from "@/app/lib/melipayamk";
import Otp from "@/models/Otp";
import User from "@/models/User";
import crypto from "crypto";
export async function POST(request) {
  await connectToDatabase();
  try {
    const { name, phone, type } = await request.json();
    if (!type || !["register", "login"].includes(type)) {
      return new Response(
        JSON.stringify({ message: "نوع درخواست نامعتبر میباشد" }),
        {
          status: 400,
        }
      );
    }
    const phoneRegex = /^(\+98|0)?9\d{9}$/;
    if (!phone || !phoneRegex.test(phone)) {
      return new Response(
        JSON.stringify({ message: "شماره تلفن وارد شده صحیح نمیباشد" }),
        {
          status: 400,
        }
      );
    }

    if (type === "register") {
      if (!name || typeof name !== "string" || name.trim() === "") {
        return new Response(
          JSON.stringify({ message: "نام کاربری الزامی میباشد" }),
          {
            status: 400,
          }
        );
      }
      if (name.length < 3 || name.length > 30) {
        return new Response(
          JSON.stringify({ message: "نام باید بین ۳ تا ۳۰ باشد" }),
          {
            status: 400,
          }
        );
      }
      const existingUser = await User.findOne({ phone });
      if (existingUser) {
        return new Response(
          JSON.stringify({
            message: "کاربر با این شماره تلفن قبلا ثبت نام کرده است",
          }),
          {
            status: 400,
          }
        );
      }
    } else if (type === "login") {
      const user = await User.findOne({ phone });
      if (!user) {
        return new Response(
          JSON.stringify({
            message: "کاربری با این شماره تلفن یافت نشد",
          }),
          {
            status: 400,
          }
        );
      }
    }

    const otpCode = crypto.randomInt(100000, 999999).toString();
    await Otp.deleteMany({ phone });
    await Otp.create({
      phone,
      code: otpCode,
      kind: type === "register" ? 1 : 2,
      expireAt: new Date(Date.now() + 10 * 60 * 1000),
    });

    await sendSms(phone, `کد تایید شما : ${otpCode}`);

    return new Response(
      JSON.stringify({ message: "کد تایید برای شما ارسال شد" }),
      { status: 200 }
    );
  } catch (error) {
    console.error("OTP API Error:", error); 
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
