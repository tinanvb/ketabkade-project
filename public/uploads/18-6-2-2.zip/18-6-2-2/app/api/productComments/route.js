import connectToDatabase from "@/app/lib/db";
import ProductComment from "@/models/ProductComment";
import mongoose from "mongoose";

export async function GET(request) {
  await connectToDatabase();
  try {
    const { searchParams } = new URL(request.url);
    const productId = searchParams.get("productId");

    let product = {};
    if (productId) {
      product.productId = productId;
    }

    const productComments = await ProductComment.find(product)
      .populate({ path: "productId", select: "name" })
      .populate({ path: "userId", select: "name phone" });

    return new Response(JSON.stringify(productComments), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}

export async function POST(request) {
  await connectToDatabase();
  try {
    const body = await request.json();
    const { firstName, lastName, comment, userId, productId } = body;

    if (!firstName || !lastName || !comment) {
      return new Response(
        JSON.stringify({ message: "همه فیلد ها الزامی هستند" }),
        {
          status: 400,
        }
      );
    }
    if (firstName.length < 3 || firstName.length > 30) {
      return new Response(
        JSON.stringify({ message: "نام باید بین ۳ تا ۳۰ کاراکتر باشد" }),
        {
          status: 400,
        }
      );
    }
    if (lastName.length < 3 || lastName.length > 30) {
      return new Response(
        JSON.stringify({
          message: "نام خانوادگی باید بین ۳ تا ۳۰ کاراکتر باشد",
        }),
        {
          status: 400,
        }
      );
    }
    if (comment.length < 3 || comment.length > 300) {
      return new Response(
        JSON.stringify({
          message: "کامنت باید بین ۳ تا ۳۰۰ کاراکتر باشد",
        }),
        {
          status: 400,
        }
      );
    }

    const newComment = await ProductComment.create({
      firstName,
      lastName,
      comment,
      userId,
      productId,
    });
    return new Response(JSON.stringify(newComment), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
