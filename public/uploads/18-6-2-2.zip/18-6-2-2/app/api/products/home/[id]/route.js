import connectToDatabase from "@/app/lib/db";
import Product from "@/models/Product";
import { NextResponse } from "next/server";
import Category from "@/models/Category";
export async function GET(req, {params}) {
  const { id } = await params;
  await connectToDatabase();
  try {
    if (!id || id.length !== 24) {
      return NextResponse.json(
        { error: "ایدی معتبر نمیباشد" },
        { status: 400 }
      );
    }
    const product = await Product.findById(id)
      .populate("category", "name")
      .select("name description price category stock viwes imageUrl");
    if (!product) {
      return NextResponse.json({ error: "محصول پیدا نشد" }, { status: 404 });
    }
    return NextResponse.json(product)
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
