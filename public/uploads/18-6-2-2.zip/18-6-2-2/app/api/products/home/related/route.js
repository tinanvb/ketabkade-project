import connectToDatabase from "@/app/lib/db";
import Product from "@/models/Product";
import { NextResponse } from "next/server";
export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const categoryId = searchParams.get("category");
  if (!categoryId) {
    return NextResponse.json(
      { error: " ایدی محصول پیدا نشد" },
      { status: 400 }
    );
  }
  await connectToDatabase();

  try {
    const relatedProduct = await Product.find({ category: categoryId })
      .limit(8)
      .select("name price imageUrl");
    if (!relatedProduct) {
      return NextResponse.json({ error: "محصول پیدا نشد" }, { status: 404 });
    }
    return NextResponse.json(relatedProduct);
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
