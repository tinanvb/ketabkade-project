import connectToDatabase from "@/app/lib/db";
import Product from "@/models/Product";
import ProductGallery from "@/models/ProductGallery";
import mongoose from "mongoose";
import { writeFile, unlink } from "fs/promises";
import { join } from "path";

export async function GET(request, { params }) {
  await connectToDatabase();
  const { id } = await params;
  console.log("Fetching gallery item with id:", id);

  try {
    const galleryItem = await ProductGallery.findById(id);
    if (!galleryItem) {
      return new Response(JSON.stringify({ message: "تصویر گالری پیدا نشد" }), {
        status: 404,
      });
    }
    return new Response(JSON.stringify(galleryItem), { status: 200 });
  } catch (error) {
    console.error("GET Product Error:", error);
    return new Response(JSON.stringify({ message: "خطا در دریافت محصول" }), {
      status: 500,
    });
  }
}

export async function PUT(request, { params }) {
  const { id } = await params;
  if (!id) {
    return NextResponse.json({
      success: false,
      message: "شناسه محصول معتبر نیست",
    });
  }
  try {

    await connectToDatabase();
    const formData = await request.formData();
    const file = formData.get("image");
    const setAsMainImage = formData.get("setAsMainImage") === "true"; 
    if (!file) {
      return new Response(JSON.stringify({ message: "تصویر الزامی است" }), {
        status: 400,
      });
    }
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const uploadDir = join(process.cwd(), "public/uploads");
    const filePath = join(uploadDir, file.name);
    await writeFile(filePath, buffer);

    const newImageUrl = `/uploads/${file.name}`;
    const galleryItem = await ProductGallery.findById(id);
    if (!galleryItem) {
      return new Response(JSON.stringify({ message: "آیتم گالری یافت نشد" }), {
        status: 404,
      });
    }

    const oldFilePath = join(process.cwd(), "public", galleryItem.imageUrl);
    await unlink(oldFilePath).catch(() => console.log("خطا در حذف تصویر قبلی"));
    galleryItem.imageUrl = newImageUrl;
    await galleryItem.save();

    if (setAsMainImage) {
      const product = await Product.findById(galleryItem.product);
      if (product) {
        product.imageUrl = newImageUrl;
        await product.save();
        console.log(" تصویر :", product.imageUrl); 
      }
    }
    return new Response(JSON.stringify(galleryItem), {
      status: 200,
    });
  } catch (err) {
    console.error("خطا در ویرایش تصویر گالری:", err);
    return new Response(JSON.stringify({ message: "خطا در سرور" }), {
      status: 500,
    });
  }
}

export async function DELETE(request, { params }) {
  const { id } = await params;
  try {
    await connectToDatabase();
    const objectId = new mongoose.Types.ObjectId(id);
    const result = await ProductGallery.findByIdAndDelete(objectId);
    if (!result) {
      return new Response(JSON.stringify({ message: "تصویر پیدا نشد" }), {
        status: 404,
      });
    }
    return new Response(JSON.stringify({ message: "با موفقیت حذف شد" }), {
      status: 200,
    });
  } catch (err) {
    return new Response(JSON.stringify({ message: err.message }), {
      status: 500,
    });
  }
}
