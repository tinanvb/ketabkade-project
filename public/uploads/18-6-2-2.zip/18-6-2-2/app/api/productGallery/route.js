import connectToDatabase from "@/app/lib/db";
import ProductGallery from "@/models/ProductGallery";
import { NextResponse } from "next/server";
import { join } from "path";
import { writeFile } from "fs/promises";
import mongoose from "mongoose";

export async function GET(request) {
    const { searchParams } = new URL(request.url);
    const productId = searchParams.get("productId");
    console.log("productId: ", productId);
    if (!productId) {
      return new Response(JSON.stringify({ message: "شناسه محصول الزامی است" }), {
        status: 400,
      });
    }
  
    try {
      await connectToDatabase();  
      const objectId = new mongoose.Types.ObjectId(productId);
      const productGallery = await ProductGallery.find({ product: objectId }).limit(5).select("imageUrl");
  
      console.log("Fetched product gallery:", productGallery);
  
      return new Response(JSON.stringify(productGallery), { status: 200 });
    } catch (error) {
      console.error("Error in ProductGallery GET:", error);
      return new Response(JSON.stringify({ message: error.message }), {
        status: 500,
      });
    }
  }
  

export async function POST(request) {
  try {
    const data = await request.formData();
    const file = data.get("image");
    const productId = data.get("productId");

    if (!file || !productId) {
      return NextResponse.json({
        success: false,
        message: "تصویر و شناسه محصول الزامی است",
      });
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const uploadDir = join(process.cwd(), "public/uploads");
    const filePath = join(uploadDir, file.name);

    await writeFile(filePath, buffer);
    await connectToDatabase();
    const objectId = new mongoose.Types.ObjectId(productId);
    const galleryItem = await ProductGallery.create({
      product: objectId,
      imageUrl: `/uploads/${file.name}`,
    });

    return new Response(JSON.stringify(galleryItem), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
