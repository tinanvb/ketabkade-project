import connectToDatabase from "@/app/lib/db";
import Brand from "@/models/Brand";
import { NextResponse } from "next/server";

export async function GET() {
  await connectToDatabase();

  try {
    const brands = await Brand.find({}).limit(4).select("name imageUrl");

    return NextResponse.json(brands, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      {
        error: "مشکلی در دریافت محصولات پربازدید رخ داده است",
      },
      { status: 500 }
    );
  }
}
