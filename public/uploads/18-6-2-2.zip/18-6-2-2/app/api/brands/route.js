import connectToDatabase from "@/app/lib/db";
import { NextResponse } from "next/server";
import { join } from "path";
import { writeFile } from "fs/promises";
import Brand from "@/models/Brand";

export async function GET(request) {
  await connectToDatabase();
  const brands = await Brand.find({});
  return new Response(JSON.stringify(brands), { status: 200 });
}

export async function POST(request) {
  try {
    await connectToDatabase();
    const data = await request.formData();
    const name = data.get("name");
    const file = data.get("image");

    if (!name || typeof name !== "string" || name.trim().length < 3) {
      return NextResponse.json(
        {
          success: false,
          message: "نام برند الزامی است و باید حداقل ۳ کاراکتر باشد",
        },
        { status: 400 }
      );
    }

    if (!file) {
      return NextResponse.json(
        {
          success: false,
          message: "آپلود تصویر برند الزامی است",
        },
        { status: 400 }
      );
    }
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const uploadDir = join(process.cwd(), "public/images/brand");
    const filePath = join(uploadDir, file.name);
    await writeFile(filePath, buffer);
    const brand = await Brand.create({
      name,
      imageUrl: `images/brand/${file.name}`,
    });

    return NextResponse.json(brand, { status: 201 });
  } catch (error) {
    return NextResponse.json({ message: error.message }, { status: 500 });
  }
}
