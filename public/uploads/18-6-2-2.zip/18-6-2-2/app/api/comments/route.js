import connectToDatabase from "@/app/lib/db";
import Comment from "@/models/Comment";
import mongoose from "mongoose";
import Product from '@/models/Product'
import User from "@/models/User";
export async function GET(request) {
  await connectToDatabase();
  const comments = await Comment.find({})
    .populate({ path: "productId", select: "name" })
    .populate({ path: "userId", select: "name phone" });
  return new Response(JSON.stringify(comments), { status: 200 });
}

export async function POST(request) {
  await connectToDatabase();
  try {
    const body = await request.json();
    const { text, isApproved = false, userId, productId } = body;

    if (!text || text.length < 3 || text.length > 300) {
      return new Response(
        JSON.stringify({ message: "نظر باید بین ۳ تا ۳۰۰ کاراکتر باشد" }),
        {
          status: 400,
        }
      );
    }
    if (isApproved !== undefined && typeof isApproved !== "boolean") {
      return new Response(
        JSON.stringify({
          message: "وضعیت تأیید نظر باید مقدار صحیح یا غلط باشد",
        }),
        { status: 400 }
      );
    }
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return new Response(
        JSON.stringify({ message: "شناسه کاربر الزامی است" }),
        { status: 400 }
      );
    }
    if (!mongoose.Types.ObjectId.isValid(productId)) {
      return new Response(
        JSON.stringify({ message: "شناسه محصول الزامی است" }),
        { status: 400 }
      );
    }
    const comment = await Comment.create(body);
    return new Response(JSON.stringify(comment), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
