import connectToDatabase from "@/app/lib/db";
import Comment from "@/models/Comment";

export async function GET(request, { params }) {
  await connectToDatabase();
  const { id } = await params;
  try {
    const comment = await Comment.findById(id);
    if (!comment) {
      return new Response(JSON.stringify({ message: "نظر پیدا نشد" }), {
        status: 404,
      });
    }
    return new Response(JSON.stringify(comment), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}


export async function DELETE(request, { params }) {
  await connectToDatabase();
  try {
    const { id } = await params;
    await Comment.findByIdAndDelete(id);
    return new Response(null, { status: 204 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
export async function PATCH(request, { params }) {
  await connectToDatabase();
  try {
    const { id } = await params;
    const { isApproved } = await request.json();
    const comments = await Comment.findById(id);
    if (!comments) {
      return new Response(JSON.stringify({ message: "نظر پیدا نشد" }), {
        status: 404,
      });
    }
    comments.isApproved = isApproved;
    await comments.save();
    return new Response(JSON.stringify(comments), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
