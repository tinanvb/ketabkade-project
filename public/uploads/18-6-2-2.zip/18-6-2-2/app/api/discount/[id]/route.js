import connectToDatabase from "@/app/lib/db";
import Category from "@/models/Category";
import Product from "@/models/Product";
import Discount from "@/models/Discount";

export async function GET(request, { params }) {
  await connectToDatabase();
  const { id } = await params;
  try {
    const discount = await Discount.findById(id);
    if (!discount) {
      return new Response(JSON.stringify({ message: "کد تخفیف پیدا نشد" }), {
        status: 404,
      });
    }
    return new Response(JSON.stringify(discount), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}

export async function PUT(request, { params }) {
  await connectToDatabase();
  try {
    const { id } = await params;
    const body = await request.json();
    const { discountCode, discountPercentage, date, isActive } = body;
    
    if (!discountCode || typeof discountCode !== "string") {
      return new Response(JSON.stringify({ message: "کد تخفیف نامعتبر است" }), {
        status: 400,
      });
    }

    if (!discountPercentage || isNaN(Number(discountPercentage))) {
      return new Response(
        JSON.stringify({ message: "درصد تخفیف نامعتبر است" }),
        { status: 400 }
      );
    }

    if (!date || isNaN(new Date(date).getTime())) {
      return new Response(JSON.stringify({ message: "تاریخ نامعتبر است" }), {
        status: 400,
      });
    }

    if (typeof isActive !== "boolean") {
      return new Response(
        JSON.stringify({ message: "وضعیت فعال بودن نامعتبر است" }),
        { status: 400 }
      );
    }
    const newDiscount = await Discount.findByIdAndUpdate(id, body, {
      new: true,
    });
    return new Response(JSON.stringify(newDiscount), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}

export async function DELETE(request, { params }) {
  await connectToDatabase();
  try {
    const { id } = await params;
    await Discount.findByIdAndDelete(id);
    return new Response(null, { status: 204 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
