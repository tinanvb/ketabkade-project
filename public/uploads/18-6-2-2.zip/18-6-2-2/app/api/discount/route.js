import connectToDatabase from "@/app/lib/db";
import Discount from "@/models/Discount";

export async function GET(request) {
  await connectToDatabase();
  const discount = await Discount.find({});
  return new Response(JSON.stringify(discount), { status: 200 });
}

export async function POST(request) {
  await connectToDatabase();
  try {
    const body = await request.json();
    const { discountCode, discountPercentage, date, isActive } = body;

    if (!discountCode || typeof discountCode !== "string") {
      return new Response(JSON.stringify({ message: "کد تخفیف نامعتبر است" }), {
        status: 400,
      });
    }

    if (!discountPercentage || isNaN(Number(discountPercentage))) {
      return new Response(
        JSON.stringify({ message: "درصد تخفیف نامعتبر است" }),
        { status: 400 }
      );
    }

    if (!date || isNaN(new Date(date).getTime())) {
      return new Response(JSON.stringify({ message: "تاریخ نامعتبر است" }), {
        status: 400,
      });
    }

    if (typeof isActive !== "boolean") {
      return new Response(
        JSON.stringify({ message: "وضعیت فعال بودن نامعتبر است" }),
        { status: 400 }
      );
    }
    const formattedDate = new Date(date).toISOString();
    const newDiscount = await Discount.create({
      discountCode,
      discountPercentage: Number(discountPercentage),
      date: formattedDate,
      isActive,
    });

    return new Response(JSON.stringify(newDiscount), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
