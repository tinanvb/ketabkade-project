import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import Sidebar from "../components/ui/Sidebar";
import Header from "../components/ui/Header";
import AuthWrapper from "../components/auth/auth";


const AdminDashboard = () => {
  return (
<AuthWrapper>
    <Container fluid>
      <Row>
        <Col md={3} className="vh-100">
          <Sidebar />
        </Col>
        <Col md={9}>
          <Header />
          <main className="content p-4">
            <h4>به پنل ادمین خوش آمدید</h4>
            <p>در این بخش میتوانید موارد مختلف فروشگاه را مدیریت کنید</p>
          </main>
        </Col>
      </Row>
    </Container>
    </AuthWrapper>
  );
};

export default AdminDashboard;
