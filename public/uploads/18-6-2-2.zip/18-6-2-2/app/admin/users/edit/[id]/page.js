"use client";
import AuthWrapper from "@/app/components/auth/auth";
import Header from "@/app/components/ui/Header";
import Sidebar from "@/app/components/ui/Sidebar";
import { useParams, useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import { Alert, Button, Col, Container, Form, Row } from "react-bootstrap";

const UpdateUser = () => {
  const { id } = useParams();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [error, setError] = useState(null);
  const [formError, setFormError] = useState("");
  const router = useRouter();

  useEffect(() => {
    fetch(`/api/users/${id}`)
      .then((res) => res.json())
      .then((data) => {
        setName(data.name || ""),
          setPhone(data.phone || ""),
          setEmail(data.email || ""),
          setIsAdmin(data.isAdmin);
      });
  }, [id]);
  const validateForm = () => {
    if (!name || name.trim() === "") {
      setFormError("نام کاربر الزامی میباشد");
      return false;
    } else if (name.length < 3) {
      setFormError("نام کاربر باید بزرگتر از ۳ کارکتر باشد");
      return false;
    }

    if (!phone) {
      setFormError("شماره موبایل الزامی میباشد");
      return false;
    } else if (phone.length !== 11) {
      setFormError("شماره موبایل باید ۱۱ رقمی باشد");
      return false;
    }
    setFormError("");
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }

    try {
      const response = await fetch(`/api/users/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          phone: phone.trim(),
          email,
          isAdmin,
        }),
      });

      if (response.status === 400) {
        let message = await response.json();
        setFormError(message.message);
        return;
      }
      if (!response.ok) throw new Error("مشکلی در ویرایش کاربر پیش آمده است");
      router.push("/admin/users");
    } catch (error) {
      setError(error.message);
    }
  };
  return (
    <AuthWrapper>
      <Container fluid>
        <Row>
          <Col md={3} className="vh-100">
            <Sidebar />
          </Col>
          <Col md={9}>
            <Header />
            <main className="p-4">
              <h2 className="my-4">ویرایش کاربر </h2>
              {error && <Alert variant="danger">{error}</Alert>}
              {formError && <Alert variant="warning">{formError}</Alert>}
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label> نام کاربر</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="نام کاربر را وارد کنید"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>شماره موبایل</Form.Label>
                  <Form.Control
                    type="tel"
                    pattern="[0-9]{11}"
                    placeholder="شماره موبایل را وارد کنید"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>ایمیل(اختیاری)</Form.Label>
                  <Form.Control
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Check
                    type="checkbox"
                    label="ادمین"
                    checked={isAdmin}
                    onChange={(e) => setIsAdmin(e.target.checked)}
                  />
                </Form.Group>
                <Button type="submit"> ذخیره کاربر</Button>
              </Form>
            </main>
          </Col>
        </Row>
      </Container>
    </AuthWrapper>
  );
};

export default UpdateUser;
