"use client";
import AuthWrapper from "@/app/components/auth/auth";
import GeneralError from "@/app/components/ui/GeneralError";
import Header from "@/app/components/ui/Header";
import LoadingSpinner from "@/app/components/ui/LoadingSpinner";
import Sidebar from "@/app/components/ui/Sidebar";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import { Alert, Col, Container, Row, Table } from "react-bootstrap";
import { AiOutlineDelete, AiOutlineEdit, AiOutlineUser } from "react-icons/ai";
const Users = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/users");
        if (!response.ok) throw new Error("مشکل در دریافت اطلاعات کاربر ");
        const data = await response.json();
        setUsers(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleDelete = async (id) => {
    try {
      await fetch(`/api/users/${id}`, { method: "DELETE" });
      setUsers(users.filter((user) => user._id !== id));
    } catch (error) {
      setError("مشکلی در حذف کاربر پیش آمد");
    }
  };
  const handleAdmin = async (id) => {
    try {
      const updatedUser = users.find((user) => user._id === id);
      if (!updatedUser) return;
      const newIsAdmin = !updatedUser.isAdmin;
      setUsers((prevUsers) =>
        prevUsers.map((user) =>
          user._id === id ? { ...user, isAdmin: newIsAdmin } : user
        )
      );
      const response = await fetch(`/api/users/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ isAdmin: newIsAdmin }),
      });
      if (response.ok) {
        setSuccessMessage("تغییر وضعیت کاربر با موفقیت انجام شد!");
        setTimeout(() => setSuccessMessage(""), 2000);
      }
    } catch (error) {
      setError("مشکلی در بروز رسانی ادمین پیش آمد");
    }
  };
  return (
    <AuthWrapper>
      <Container fluid>
        <Row>
          <Col md={3} className="vh-100">
            <Sidebar />
          </Col>
          <Col md={9}>
            <Header />
            <main className="p-4">
              <h4 className="my-4">مدیریت محصولات</h4>
              {successMessage && (
                <Alert dismissible variant="success">
                  {successMessage}
                </Alert>
              )}
              {error && <GeneralError error={error} />}
              {loading ? (
                <LoadingSpinner />
              ) : (
                <>
                  <Link
                    href="users/add"
                    className="btn-custom-add mb-3 px-2 py-1 rounded"
                  >
                    <AiOutlineUser />
                    افزودن کاربر جدید
                  </Link>
                  <Table striped bordered hover>
                    <thead>
                      <tr>
                        <th>شناسه</th>
                        <th>نام</th>
                        <th>موبایل</th>
                        <th>ایمیل</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((user, index) => {
                        return (
                          <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{user.name}</td>
                            <td>{user.phone}</td>
                            <td>{user.email}</td>
                            <td>
                              {user.isAdmin ? (
                                <div className="bg-primary btn-user">ادمین</div>
                              ) : (
                                <div className="bg-secondary btn-user">
                                  کاربر عادی
                                </div>
                              )}
                            </td>
                            <td>
                              <div className="btn-group-inline">
                                <button
                                  className="btn-add-user"
                                  onClick={() => handleAdmin(user._id)}
                                >
                                  {user.isAdmin
                                    ? "تبدیل به کاربر"
                                    : "تبدیل به ادمین"}
                                </button>
                                <Link
                                  href={`/admin/users/edit/${user._id}`}
                                  className="btn-edit-user "
                                >
                                  <AiOutlineEdit />
                                  ویرایش
                                </Link>
                                <button
                                  onClick={() => handleDelete(user._id)}
                                  className="btn-custom-delete"
                                >
                                  <AiOutlineDelete />
                                  حذف
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </Table>
                </>
              )}
            </main>
          </Col>
        </Row>
      </Container>
    </AuthWrapper>
  );
};

export default Users;
