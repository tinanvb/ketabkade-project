"use client";
import AuthWrapper from "@/app/components/auth/auth";
import Header from "@/app/components/ui/Header";
import Sidebar from "@/app/components/ui/Sidebar";
import { useRouter } from "next/navigation";
import React, { use, useEffect, useState } from "react";
import { Alert, Button, Col, Container, Form, Row } from "react-bootstrap";

const AddUser = () => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [error, setError] = useState(null);
  const [formError, setFormError] = useState("");
  const router = useRouter();
  useEffect(() => {
    setFormError("");
  }, [name]);
  const validateForm = () => {
    if (!name) {
      setFormError("نام کاربر الزامی میباشد");
      return false;
    } else if (name.length < 3) {
      setFormError("نام کاربر باید بزرگتر از ۳ کارکتر باشد");
      return false;
    }

    if (!phone || phone.trim() === "") {
      setFormError("شماره موبایل الزامی میباشد");
      return false;
    } else if (phone.length != 11) {
      setFormError(" شماره موبایل باید ۱۱ رقمی باشد");
      return false;
    }
    setFormError("");
    return true;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }
    try {
      const response = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          phone: phone.trim(),
          email: email.trim() || null,
          isAdmin,
        }),
      });

      if (!response.ok) {
        const message = await response.json();
        setFormError(message.message || "مشکلی در ساخت کاربر پیش آمده است");
        return;
      }
      router.push("/admin/users");
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <AuthWrapper>
      <Container fluid>
        <Row>
          <Col md={3} className="vh-100">
            <Sidebar />
          </Col>
          <Col md={9}>
            <Header />
            <main className="p-4">
              <h2 className="my-4">افزودن کاربر جدید</h2>
              {error && <Alert variant="danger">{error}</Alert>}
              {formError && <Alert variant="warning">{formError}</Alert>}

              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label> نام کاربر</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="نام کاربر را وارد کنید"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>شماره موبایل</Form.Label>
                  <Form.Control
                    type="tel"
                    placeholder="شماره موبایل را وارد کنید"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>ایمیل(اختیاری)</Form.Label>
                  <Form.Control
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Check
                    type="checkbox"
                    label="ادمین"
                    checked={isAdmin}
                    onChange={(e) => setIsAdmin(e.target.checked)}
                  />
                </Form.Group>

                <Button type="submit"> ذخیره کاربر</Button>
              </Form>
            </main>
          </Col>
        </Row>
      </Container>
    </AuthWrapper>
  );
};

export default AddUser;
