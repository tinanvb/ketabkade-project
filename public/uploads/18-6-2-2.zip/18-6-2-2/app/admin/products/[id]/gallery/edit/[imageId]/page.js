"use client";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Container, Row, Col, Form, Button, Alert } from "react-bootstrap";
import Sidebar from "@/app/components/ui/Sidebar";
import Header from "@/app/components/ui/Header";
import LoadingSpinner from "@/app/components/ui/LoadingSpinner";

const EditGalleryImage = () => {
  const { id, imageId } = useParams();
  const [image, setImage] = useState(null);
  const [currentImage, setCurrentImage] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const router = useRouter();
  useEffect(() => {
    const fetchImage = async () => {
      try {
        const res = await fetch(`/api/productGallery/${imageId}`);
        if (!res.ok) throw new Error("مشکل در دریافت تصویر");
        const data = await res.json();
        setCurrentImage(data.imageUrl);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchImage();
  }, [imageId]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!image) {
      setError("لطفاً یک تصویر جدید انتخاب کنید");
      return;
    }

    try {
      const formData = new FormData();
      formData.append("image", image);
      const res = await fetch(`/api/productGallery/${imageId}`, {
        method: "PUT",
        body: formData,
      });

      if (!res.ok) throw new Error("ویرایش تصویر ناموفق بود");

      router.push(`/admin/products/${id}/gallery`);
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <Container fluid>
      <Row>
        <Col md={3}>
          <Sidebar />
        </Col>
        <Col md={9}>
          <Header />
          <main className="p-4">
            <h4>ویرایش تصویر گالری</h4>
            {error && <Alert variant="danger">{error}</Alert>}
            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3">
                {currentImage && (
                  <div className="mt-3">
                    <strong>تصویر فعلی:</strong>
                    <br />
                    <img
                      src={currentImage}
                      alt="تصویر گالری"
                      style={{ maxWidth: "200px", borderRadius: "8px" }}
                    />
                  </div>
                )}
                <Form.Label>تصویر جدید</Form.Label>
                <Form.Control
                  type="file"
                  accept="image/*"
                  onChange={(e) => setImage(e.target.files[0])}
                />
              </Form.Group>

              <Button type="submit">ذخیره تصویر</Button>
            </Form>
          </main>
        </Col>
      </Row>
    </Container>
  );
};

export default EditGalleryImage;
