"use client";
import { useParams, useRouter } from "next/navigation";
import { useState } from "react";
import { Container, Row, Col, Form, Button, Alert } from "react-bootstrap";
import Sidebar from "@/app/components/ui/Sidebar";
import Header from "@/app/components/ui/Header";

const AddGalleryImage = () => {
  const { id } = useParams();
  const [image, setImage] = useState(null);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append("image", image);
      formData.append("productId", id);

      const res = await fetch("/api/productGallery", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) throw new Error("ثبت تصویر ناموفق بود");
    } catch (err) {
      setError(err.message);
    }
    if (!image) {
      setError("لطفاً یک تصویر انتخاب کنید");
      return;
    }
  };

  return (
    <Container fluid>
      <Row>
        <Col md={3}>
          <Sidebar />
        </Col>
        <Col md={9}>
          <Header />
          <main className="p-4">
            <h4>افزودن تصویر به گالری</h4>
            {error && <Alert variant="danger">{error}</Alert>}
            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3">
                <Form.Label>تصویر جدید</Form.Label>
                <Form.Control
                  type="file"
                  accept="image/*"
                  onChange={(e) => setImage(e.target.files[0])}
                />
              </Form.Group>

              <Button type="submit">ذخیره تصویر</Button>
            </Form>
          </main>
        </Col>
      </Row>
    </Container>
  );
};

export default AddGalleryImage;
