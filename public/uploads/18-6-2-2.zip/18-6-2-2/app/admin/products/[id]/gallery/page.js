"use client";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { Container, Row, Col, Button, Table } from "react-bootstrap";
import Sidebar from "@/app/components/ui/Sidebar";
import Header from "@/app/components/ui/Header";
import LoadingSpinner from "@/app/components/ui/LoadingSpinner";
import GeneralError from "@/app/components/ui/GeneralError";
import { AiOutlineDelete , AiOutlineEdit} from "react-icons/ai";
import Link from "next/link";

const ProductGallery = () => {
  const { id } = useParams();
  const [gallerys, setGallerys] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchGallery = async () => {
      try {
        const res = await fetch(`/api/productGallery?productId=${id}`);
        if (!res.ok) throw new Error("مشکل در دریافت تصاویر گالری");
        const data = await res.json();
        setGallerys(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchGallery();
  }, [id]);

  const handleDelete = async (id) => {
    try {
      const res = await fetch(`/api/productGallery/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("حذف ناموفق بود");
      setGallerys(gallerys.filter((gallery) => gallery._id !== id));
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <Container fluid>
      <Row>
        <Col md={3}>
          <Sidebar />
        </Col>
        <Col md={9}>
          <Header />
          <main className="p-4">
            <div className="d-flex justify-content-between">
            <h4 className="mb-4">گالری محصول</h4>
            <Link
                    href={`/admin/products/${id}/gallery/add`}
                    className="btn-custom-add mb-3 px-2 py-1 rounded"
                  >
                    ساخت
                  </Link>
            </div>
           

            {error && <GeneralError error={error} />}
            {loading ? (
              <LoadingSpinner />
            ) : (
              <>
                <Table striped bordered hover>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>تصویر</th>
                      <th>تنظیمات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {gallerys.map((gallery, index) => (
                      <tr key={gallery._id}>
                        <td>{index + 1}</td>
                        <td>
                          <img
                            src={gallery.imageUrl}
                            alt=""
                            width={60}
                            height={60}
                          />
                        </td>
                        <td>
                          <div className="btn-group-inline">
                            <Link
                              href={`/admin/products/${id}/gallery/edit/${gallery._id}`}
                              className="btn-custom-edit"
                            >
                              <AiOutlineEdit />
                            </Link>
                            <Button
                              variant="danger"
                              onClick={() => handleDelete(gallery._id)}
                                className="btn-custom-delete"
                            >
                              <AiOutlineDelete />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </>
            )}
          </main>
        </Col>
      </Row>
    </Container>
  );
};

export default ProductGallery;
