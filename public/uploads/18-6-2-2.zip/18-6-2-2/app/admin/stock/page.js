"use client";
import AuthWrapper from "@/app/components/auth/auth";
import GeneralError from "@/app/components/ui/GeneralError";
import Header from "@/app/components/ui/Header";
import LoadingSpinner from "@/app/components/ui/LoadingSpinner";
import Sidebar from "@/app/components/ui/Sidebar";
import React, { useEffect, useState } from "react";
import {
  Col,
  Container,
  Row,
  Table,
  Button,
  Form,
  Alert,
} from "react-bootstrap";

const Stock = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stockValues, setStockValues] = useState({});
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/products");
        if (!response.ok) throw new Error("مشکل در دریافت محصولات");
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const handleStockChange = (id, value) => {
    setStockValues((prev) => ({
      ...prev,
      [id]: value,
    }));
  };

  const handleUpdate = async (id) => {
    const newStockValue = stockValues[id];
    try {
      const response = await fetch(`/api/products/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ stock: newStockValue }),
      });
      if (response.ok) {
        setSuccessMessage("تعداد محصول با موفقیت تغییر یافت!");
        setTimeout(() => setSuccessMessage(""), 2000);
      }
      if (!response.ok) throw new Error("مشکل در بروزرسانی محصول");

      const updatedProduct = await response.json();
      setProducts((prevProducts) =>
        prevProducts.map((product) =>
          product._id === id
            ? { ...product, stock: updatedProduct.stock }
            : product
        )
      );
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <AuthWrapper>
      <Container fluid>
        <Row>
          <Col md={3} className="vh-100">
            <Sidebar />
          </Col>
          <Col md={9}>
            <Header />
            <main className="p-4">
              <h4 className="my-4">مدیریت انبار موجودی</h4>
              {successMessage && (
                <Alert dismissible variant="success">
                  {successMessage}
                </Alert>
              )}
              {error && <GeneralError error={error} />}
              {loading ? (
                <LoadingSpinner />
              ) : (
                <Table striped bordered hover>
                  <thead>
                    <tr>
                      <th>شناسه</th>
                      <th>نام محصول</th>
                      <th>موجودی</th>
                      <th>عملیات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product, index) => (
                      <tr key={product._id}>
                        <td>{index + 1}</td>
                        <td>{product.name}</td>
                        <td>
                          <Form.Control
                            type="number"
                            min="0"
                            value={stockValues[product._id] ?? product.stock}
                            onChange={(e) =>
                              handleStockChange(product._id, e.target.value)
                            }
                            className="w-100 d-inline"
                          />
                        </td>
                        <td>
                          <Button
                            variant="success"
                            size="sm"
                            onClick={() => handleUpdate(product._id)}
                          >
                            ذخیره
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              )}
            </main>
          </Col>
        </Row>
      </Container>
    </AuthWrapper>
  );
};

export default Stock;
