"use client";
import React, { useState } from "react";
import Header from "@/app/components/ui/Header";
import Sidebar from "@/app/components/ui/Sidebar";
import { Col, Container, Row, Form, Button, Alert } from "react-bootstrap";
import { useRouter } from "next/navigation";
import DatePicker from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";
import persian_fa from "react-date-object/locales/persian_fa";
import AuthWrapper from "@/app/components/auth/auth";

const Discount = () => {
  const [discountCode, setDiscountCode] = useState("");
  const [discountPercentage, setDiscountPercentage] = useState("");
  const [date, setDate] = useState(null);
  const [isActive, setIsActive] = useState(false);
  const [error, setError] = useState(null);
  const [formError, setFormError] = useState("");
  const router = useRouter();
  const today = new Date();

  const validateForm = () => {
    if (discountCode.trim() === "") {
      setFormError("نام کد تخفیف الزامی میباشد");
      return false;
    } else if (discountCode.length < 2 || discountCode.length > 100) {
      setFormError("کد تخفیف باید بین ۲ تا ۱۰۰ کاراکتر باشد");
      return false;
    }
    if (!discountPercentage || isNaN(discountPercentage)) {
      setFormError("درصد کد تخفیف باید یک عدد باشد");
      return false;
    } else if (discountPercentage < 0 || discountPercentage >= 100) {
      setFormError("کد تخفیف باید بین ۱ تا ۱۰۰ درصد باشد");
      return false;
    }
    if (!date) {
      setFormError("تاریخ انقضا الزامی است");
      return false;
    }
    setFormError("");
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }

    try {
      const response = await fetch("/api/discount", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          discountCode,
          discountPercentage: Number(discountPercentage),
          date: date ? date.toDate() : null,
          isActive,
        }),
      });

      if (response.status === 400) {
        let message = await response.json();
        setFormError(message.message);
      }
      if (!response.ok) throw new Error("مشکلی در ثبت کد تخفیف پیش آمده است");

      router.push("/admin/discount");
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <AuthWrapper>
      <Container fluid>
        <Row>
          <Col md={3} className="vh-100">
            <Sidebar />
          </Col>
          <Col md={9}>
            <Header />
            <main className="p-4">
              <h2 className="my-4">افزودن کد تخفیف جدید</h2>
              {error && <Alert variant="danger">{error}</Alert>}
              {formError && <Alert variant="warning">{formError}</Alert>}

              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>کد تخفیف</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="کد تخفیف را وارد کنید"
                    value={discountCode}
                    onChange={(e) => setDiscountCode(e.target.value)}
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>درصد تخفیف</Form.Label>
                  <Form.Control
                    type="number"
                    min="1"
                    max="100"
                    value={discountPercentage}
                    onChange={(e) => setDiscountPercentage(e.target.value)}
                  />
                </Form.Group>

                <Form.Group className="mb-3 ">
                  <Form.Label>تاریخ انقضا</Form.Label>

                  <div className="mt-2 ">
                    <DatePicker
                      value={date}
                      onChange={setDate}
                      calendar={persian}
                      locale={persian_fa}
                      minDate={today}
                      containerStyle={{ width: "100%" }}
                      inputclassName="form-control"
                    />
                  </div>
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Check
                    type="checkbox"
                    label="فعال "
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                  />
                </Form.Group>

                <Button type="submit">ذخیره کد تخفیف</Button>
              </Form>
            </main>
          </Col>
        </Row>
      </Container>
    </AuthWrapper>
  );
};

export default Discount;
