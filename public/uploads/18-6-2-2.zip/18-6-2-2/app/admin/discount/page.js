"use client";
import React from "react";
import GeneralError from "@/app/components/ui/GeneralError";
import Header from "@/app/components/ui/Header";
import LoadingSpinner from "@/app/components/ui/LoadingSpinner";
import Sidebar from "@/app/components/ui/Sidebar";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Col, Container, Row, Table } from "react-bootstrap";
import {
  AiOutlineDelete,
  AiOutlineEdit,
  AiOutlinePercentage,
} from "react-icons/ai";
import persian from "react-date-object/calendars/persian";
import persian_fa from "react-date-object/locales/persian_fa";
import DateObject from "react-date-object";
import AuthWrapper from "@/app/components/auth/auth";

const Discount = () => {
  const [discounts, setDiscounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchDiscount = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/discount");
        if (!response.ok) throw new Error("مشکل در مدیریت کد تخفیف");
        const data = await response.json();
        setDiscounts(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchDiscount();
  }, []);

  const handleDelete = async (id) => {
    try {
      await fetch(`/api/discount/${id}`, { method: "DELETE" });
      setDiscounts(discounts.filter((discount) => discount._id !== id));
    } catch (error) {
      setError("مشکلی در حذف پیش آمد");
    }
  };

  return (
    <AuthWrapper>
      <Container fluid>
        <Row>
          <Col md={3} className="vh-100">
            <Sidebar />
          </Col>
          <Col md={9}>
            <Header />
            <main className="p-4">
              <h4 className="my-4">مدیریت کدهای تخفیف</h4>
              {error && <GeneralError error={error} />}
              {loading ? (
                <LoadingSpinner />
              ) : (
                <>
                  <Link
                    href="discount/add"
                    className="btn-custom-add mb-3 px-2 py-1 rounded"
                  >
                    <AiOutlinePercentage />
                    افزودن کد تخفیف جدید
                  </Link>
                  <Table striped bordered hover>
                    <thead>
                      <tr>
                        <th>شناسه</th>
                        <th>کد تخفیف</th>
                        <th>درصد تخفیف</th>
                        <th>تاریخ انقضا</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {discounts.map((discount, index) => {
                        return (
                          <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{discount.discountCode}</td>
                            <td>{discount.discountPercentage}%</td>
                            <td>
                              {discount.date
                                ? new DateObject({
                                    date: discount.date,
                                    calendar: persian,
                                    locale: persian_fa,
                                  }).format("YYYY/MM/DD")
                                : "بدون تاریخ"}
                            </td>
                            <td>{discount.isActive ? "فعال" : "غیرفعال"}</td>
                            <td>
                              <div className="btn-group-inline">
                                <Link
                                  href={`/admin/discount/edit/${discount._id}`}
                                  className="btn-custom-edit"
                                >
                                  <AiOutlineEdit />
                                </Link>
                                <button
                                  onClick={() => handleDelete(discount._id)}
                                  className="btn-custom-delete"
                                >
                                  <AiOutlineDelete />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </Table>
                </>
              )}
            </main>
          </Col>
        </Row>
      </Container>
    </AuthWrapper>
  );
};

export default Discount;
