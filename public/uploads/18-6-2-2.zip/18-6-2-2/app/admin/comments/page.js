"use client";
import AuthWrapper from "@/app/components/auth/auth";
import GeneralError from "@/app/components/ui/GeneralError";
import Header from "@/app/components/ui/Header";
import LoadingSpinner from "@/app/components/ui/LoadingSpinner";
import Sidebar from "@/app/components/ui/Sidebar";
import React, { useEffect, useState } from "react";
import { Col, Container, Row, Table, Alert } from "react-bootstrap";
import {
  AiOutlineCheck,
  AiOutlineClose,
  AiOutlineDelete,
} from "react-icons/ai";

const Comments = () => {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    const fetchComments = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/productComments");
        if (!response.ok) throw new Error("مشکل در دریافت نظرات ");
        const data = await response.json();
        console.log(data);
        setComments(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchComments();
  }, []);

  const handleDelete = async (id) => {
    try {
      await fetch(`/api/productComments/${id}`, { method: "DELETE" });
      setComments(comments.filter((comment) => comment._id !== id));
    } catch (error) {
      setError("مشکلی در حذف پیش آمد");
    }
  };

  const handleApproved = async (id) => {
    try {
      const updatedComment = comments.find((comment) => comment._id === id);
      if (!updatedComment) return;
      const newApprovalStatus = !updatedComment.isApproved;
      setComments((prevComments) =>
        prevComments.map((comment) =>
          comment._id === id
            ? { ...comment, isApproved: newApprovalStatus }
            : comment
        )
      );

      const response = await fetch(`/api/productComments/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ isApproved: newApprovalStatus }),
      });

      if (response.ok) {
        setSuccessMessage("وضعیت تایید با موفقیت تغییر یافت!");
        setTimeout(() => setSuccessMessage(""), 2000);
      }
    } catch (error) {
      setError("مشکلی در بروز رسانی وضعیت تایید پیش آمد");
    }
  };

  return (
    <AuthWrapper>
      <Container fluid>
        <Row>
          <Col md={3} className="vh-100">
            <Sidebar />
          </Col>
          <Col md={9}>
            <Header />
            <main className="p-4">
              <h4 className="my-4">مدیریت نظرات</h4>
              {successMessage && (
                <Alert dismissible variant="success">
                  {successMessage}
                </Alert>
              )}
              {error && <GeneralError error={error} />}
              {loading ? (
                <LoadingSpinner />
              ) : (
                <>
                  <Table striped bordered hover>
                    <thead>
                      <tr>
                        <th>شناسه</th>
                        <th>نام کاربر</th>
                        <th>موبایل کاربر</th>
                        <th>نظر</th>
                        <th>محصول</th>
                        <th>وضعیت تایید</th>
                        <th>تاریخ ثبت</th>
                        <th>عملیات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {comments.map((comment, index) => {
                        return (
                          <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{comment.userId?.name || "بدون نام"}</td>
                            <td>
                              {comment.userId?.phone || "بدون شماره موبایل"}
                            </td>
                            <td>{comment.comment}</td>
                            <td>
                              {comment.productId?.name || "بدون نام محصول"}
                            </td>
                            <td>
                              {comment.isApproved ? (
                                <div className="text-bg-success rounded w-75 text-center flex-column">
                                  "تایید شده"
                                </div>
                              ) : (
                                <div className="text-bg-danger rounded w-75 text-center flex-column">
                                  "تایید نشده"
                                </div>
                              )}
                            </td>
                            <td>
                              {new Date(comment.updatedAt).toLocaleDateString(
                                "fa-IR"
                              )}
                            </td>
                            <td>
                              <div className="btn-group-inline">
                                <button
                                  onClick={() => handleApproved(comment._id)}
                                  className="btn-custom-close"
                                >
                                  {comment.isApproved ? (
                                    <AiOutlineClose />
                                  ) : (
                                    <AiOutlineCheck />
                                  )}
                                </button>
                                <button
                                  onClick={() => handleDelete(comment._id)}
                                  className="btn-custom-delete"
                                >
                                  <AiOutlineDelete />
                                </button>
                                
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </Table>
                </>
              )}
            </main>
          </Col>
        </Row>
      </Container>
    </AuthWrapper>
  );
};

export default Comments;
