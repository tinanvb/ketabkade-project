import React from "react";
import { Button } from "react-bootstrap";

const Home = () => {
  return (
    <div>
      <h1> Hello Home</h1>
      <Button>log out</Button>
    </div>
  );
};

export default Home;
