import React from "react";
import { Navbar, NavbarBrand } from "react-bootstrap";

const Header = () => {
  return (
    <Navbar expand="lg" className="d-flex justify-content-between rounded dashboard-bg">
      <NavbarBrand>داشبورد</NavbarBrand>
    </Navbar>
  );
};

export default Header;
