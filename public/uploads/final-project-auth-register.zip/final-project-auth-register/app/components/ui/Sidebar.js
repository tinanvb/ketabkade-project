"use client";
import Link from "next/link";
import React from "react";
import { Nav } from "react-bootstrap";
import { FaChartPie, FaLayerGroup, FaShoppingBag, FaTags } from "react-icons/fa";
import { usePathname } from "next/navigation";

const Sidebar = () => {
  const pathname = usePathname();

  const isActive = (path) => pathname === path;

  return (
    <aside className="sidebar">
      <div className="admin-profile text-center py-2 ">
        <img src="/avatar.png" alt="Admin Avatar" className="admin-avatar mb-2" />
        <h6 className="mb-0 text-white">نام مدیر پنل ادمین</h6>
        <p className="admin-role mt-2">مدیریت پنل ادمین</p>
      </div>

      <Nav className="flex-column">
        <Link href="/admin" className={isActive("/admin") ? "active-link" : ""}>
          <FaChartPie />
          داشبورد
        </Link>
        <Link href="/admin/products" className={isActive("/admin/products") ? "active-link" : ""}>
          <FaShoppingBag />
          مدیریت محصولات
        </Link>
        <Link href="/admin/categories" className={isActive("/admin/categories") ? "active-link" : ""}>
          <FaLayerGroup />
          مدیریت دسته بندی ها
        </Link>
        <Link href="/admin/tags" className={isActive("/admin/tags") ? "active-link" : ""}>
          <FaTags />
          مدیریت برچسب ها
        </Link>
      </Nav>
    </aside>
  );
};

export default Sidebar;
