"use client";
import React, { useEffect, useState } from "react";
import TextInput from "../../common/TextInput";
import { toast } from "react-toastify";
import { emailRegex, phoneNumberRegex } from "@/app/utils/regex";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";

const LoginForm = () => {
  const [form, setForm] = useState({ identifier: "", password: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const router = useRouter();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});
    const newErrors = {};

    if (!form.identifier.trim()) {
      newErrors.identifier = "ایمیل یا شماره موبایل الزامی است.";
    } else if (
      !emailRegex.test(form.identifier.trim()) &&
      !phoneNumberRegex.test(form.identifier.trim())
    ) {
      newErrors.identifier = "فرمت ایمیل یا شماره موبایل معتبر نیست.";
    }

    if (!form.password.trim()) {
      newErrors.password = "رمز عبور الزامی است.";
    }
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) {
      setLoading(false);
      return;
    }
    const result = await signIn("credentials", {
      redirect: false,
      identifier: form.identifier,
      password: form.password,
    });
    if (result?.ok) {
      toast.success("ورود با موفقیت انجام شد.");
      router.push("/");
    } else {
      toast.error("ورود ناموفق بود. لطفاً اطلاعات را بررسی کنید.");
    }

    setLoading(false);
  };

  return (
    <div className="col-4">
      <form onSubmit={handleSubmit} className="row">
        <TextInput
          label="ایمیل / شماره موبایل"
          name="identifier"
          type="text"
          value={form.identifier}
          onChange={handleChange}
          error={errors.identifier}
          required
          wrapperClassName="col-12"
        />
        <TextInput
          label="رمز عبور"
          name="password"
          type="password"
          value={form.password}
          onChange={handleChange}
          error={errors.password}
          required
          wrapperClassName="col-12"
        />

        <button
          type="submit"
          className="btn-custom-add d-block w-50 mt-5 mx-auto"
          disabled={loading}
        >
          {loading ? "در حال ورود..." : "ورود"}
        </button>
      </form>
    </div>
  );
};

export default LoginForm;
