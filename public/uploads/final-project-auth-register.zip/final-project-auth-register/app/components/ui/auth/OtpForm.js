"use client";
import React, { useEffect, useState } from "react";
import TextInput from "../../common/TextInput";
import { useSearchParams, useRouter } from "next/navigation";
import { toast } from "react-toastify";
import { otpRegex, phoneNumberRegex } from "@/app/utils/regex";

const OtpForm = () => {
  const [form, setForm] = useState({ phoneNumber: "", otpCode: "" });
  const [isPhoneDisabled, setIsPhoneDisabled] = useState(false);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const searchParams = useSearchParams();
  const router = useRouter();

  useEffect(() => {
    const phone = searchParams.get("phoneNumber");
    if (phone) {
      setForm((prev) => ({ ...prev, phoneNumber: phone }));
      setIsPhoneDisabled(true);
    }
  }, [searchParams]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});
    const newErrors = {};

    if (
      !form.phoneNumber.trim() ||
      !phoneNumberRegex.test(form.phoneNumber.trim())
    ) {
      newErrors.phoneNumber = "شماره موبایل وارد شده معتبر نیست.";
    }
    if (!form.otpCode.trim() || !otpRegex.test(form.otpCode.trim())) {
      newErrors.otpCode = "کد تأیید یک عدد ۶ رقمی باشد";
    }
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) {
      setLoading(false);
      return;
    }

    try {
      const res = await fetch("/api/auth/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phoneNumber: form.phoneNumber,
          otpCode: form.otpCode,
          type: searchParams.get("type"),
        }),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success("تأیید با موفقیت انجام شد.");
        setTimeout(() => router.push("/"), 2000);
        return () => clearTimeout(timeout);
      } else {
        toast.error(data.message || "خطا در تایید کد");
        setErrors({ otpCode: data.message });
      }
    } catch (err) {
      toast.error("خطا در ارتباط با سرور");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="col-4">
      <form onSubmit={handleSubmit} className="row">
        <TextInput
          label="شماره موبایل"
          name="phoneNumber"
          type="tel"
          value={form.phoneNumber}
          onChange={handleChange}
          error={errors.phoneNumber}
          required
          wrapperClassName="col-12"
          disabled={isPhoneDisabled}
        />
        <TextInput
          label="کد تایید"
          name="otpCode"
          type="text"
          value={form.otpCode}
          onChange={handleChange}
          error={errors.otpCode}
          required
          wrapperClassName="col-12"
        />

        <button
          type="submit"
          className="btn-custom-add d-block w-50 mt-5 mx-auto"
          disabled={loading}
        >
          {loading ? "در حال ارسال..." : "تایید کد"}
        </button>
      </form>
    </div>
  );
};

export default OtpForm;
