import React from "react";
import "@/app/styles/TextInput.css";
import { Col } from "react-bootstrap";

export default function TextInput({
  label,
  type = "text",
  name,
  value,
  onChange,
  required = false,
  error,
  inputClassName = "",
  wrapperClassName = "",
    disabled = false,

}) {
  return (
    <>
      <Col
        className={`form-group position-relative styled-input mt-3 ${wrapperClassName}`}
      >
        <input
          type={type}
          name={name}
          id={name}
          value={value}
          onChange={onChange}
          className={`form-control ${
            error ? "is-invalid" : ""
          } ${inputClassName}`}
          placeholder=" "
          // required={required}
          autoComplete="off"
            disabled = { disabled }

        />
        <label htmlFor={name}>{label}</label>
      </Col>
      {error && <div className="invalid-feedback d-block">{error}</div>}
    </>
  );
}
