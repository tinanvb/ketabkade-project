export const phoneNumberRegex = /^(\+98|0)?9\d{9}$/;
export const emailRegex = /^[\w.-]+@[a-zA-Z\d-]+\.[a-zA-Z]{2,}$/;
export const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
export const nameRegex = /^[آ-یءٔ\s]{2,30}$/;
export const passwordRegex =
  /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
export const otpRegex=/^\d{6}$/;