"use client";
import GeneralError from "@/app/components/ui/GeneralError";
import Header from "@/app/components/ui/Header";
import LoadingSpinner from "@/app/components/ui/LoadingSpinner";
import Sidebar from "@/app/components/ui/Sidebar";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import { Col, Container, Row, Table } from "react-bootstrap";
import { AiOutlineDelete, AiOutlineEdit, AiOutlinePlus } from "react-icons/ai";

const Tags = () => {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  useEffect(() => {
    const fetchTags = async () => {
      setLoading(true);
      try {
        const res = await fetch("/api/tags");

        if (!res.ok)
          throw new Error("  مشکلی در دریافت برچسب ها  پیش امده است ");
        const data = await res.json();
        data.sort((a, b) => a.name.localeCompare(b.name));
        setTags(data);
      } catch (error) {
        setError(error?.message || "خطایی رخ داده است");
      } finally {
        setLoading(false);
      }
    };
    fetchTags();
  }, []);

  const handleDelete = async (id) => {
    try {
      await fetch(`/api/tags/${id}`, { method: "DELETE" });
      setTags(tags.filter((tag) => tag._id !== id));
    } catch (error) {
      setError("مشکلی در حذف دسته بندی پیش آمد");
    }
  };
  return (
    <Container fluid>
      <Row>
        <Col md={3} className="vh-100">
          <Sidebar />
        </Col>
        <Col md={9}>
          <Header />
          <main className="p-4">
            <div className="d-flex justify-content-between align-items-center m-3">
              <h4 className="my-4">مدیریت برچسب ها</h4>

              <Link href="tags/add" className="btn-custom-add">
                <AiOutlinePlus />
                افزودن
              </Link>
            </div>
            {error && <GeneralError error={error} />}
            {loading ? (
              <LoadingSpinner />
            ) : (
              <>
                <Table
                  striped
                  bordered
                  hover
                  className="bg-purple-100 text-dark"
                >
                  <thead>
                    <tr>
                      <th>شناسه</th>
                      <th className="text-center">نام</th>
                      <th className="text-center align-middle">وضعیت</th>
                      <th className="text-center align-middle">عملیات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tags.map((tag, index) => {
                      return (
                        <tr key={index}>
                          <td>{index + 1}</td>
                          <td className="text-center align-middle">
                            {tag.name}
                          </td>
                          <td >
                            {tag.isActive ? (
                              <div className="text-black rounded w-75 d-flex justify-content-center align-items-center mx-auto">
                                فعال
                              </div>
                            ) : (
                              <div className="text-danger rounded w-75 d-flex justify-content-center align-items-center mx-auto">
                                غیرفعال
                              </div>
                            )}
                          </td>
                          <td className="text-center align-middle">
                            <div className="btn-group-inline text-center">
                              <Link
                                href={`/admin/tags/edit/${tag._id}`}
                                className="btn-custom-edit"
                              >
                                <AiOutlineEdit />
                                ویرایش
                              </Link>
                              <button
                                onClick={() => handleDelete(tag._id)}
                                className="btn-custom-delete"
                              >
                                <AiOutlineDelete />
                                حذف
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </Table>
              </>
            )}
          </main>
        </Col>
      </Row>
    </Container>
  );
};

export default Tags;
