import React from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import Sidebar from '../components/ui/Sidebar';
import Header from '../components/ui/Header';

const AdminDashboard = () => {
    return (
        <Container fluid>
        <Row>
          <Col md={3} className="vh-100">
            <Sidebar />
          </Col>
          <Col md={9}>
            <Header/>
            <main className="content p-4">
              <h4>به پنل ادمین خوش آمدید</h4>
            </main>
          </Col>
        </Row>
      </Container>
    );
};

export default AdminDashboard;