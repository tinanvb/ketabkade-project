import connectToDatabase from "@/app/lib/db";
import { otpRegex, phoneNumberRegex } from "@/app/utils/regex";
import Otp from "@/models/Otp";
import User from "@/models/User";

export async function POST(request) {
  await connectToDatabase();

  try {
    const { phoneNumber, otpCode, type } = await request.json();

    if (!phoneNumber || !otpCode || !type) {
      return new Response(
        JSON.stringify({ message: "اطلاعات ارسالی ناقص است" }),
        { status: 400 }
      );
    }
    if (!phoneNumber.trim() || !phoneNumberRegex.test(phoneNumber.trim())) {
      return Response.json(
        { success: false, message: "شماره موبایل وارد شده معتبر نیست." },
        { status: 400 }
      );
    }
    if (!otpCode.trim() || !otpRegex.test(otpCode.trim())) {
      return new Response(
        JSON.stringify({ message: "کد تأیید یک عدد ۶ رقمی باشد" }),
        { status: 400 }
      );
    }

    const otp = await Otp.findOne({ phoneNumber, code: otpCode });

    if (!otp) {
      return new Response(
        JSON.stringify({ message: "کد وارد شده صحیح نمی‌باشد" }),
        { status: 400 }
      );
    }

    if (otp.expiresAt < new Date()) {
      return new Response(
        JSON.stringify({ message: "کد وارد شده منقضی شده است" }),
        { status: 400 }
      );
    }

    // اجرای عملیات بر اساس نوع درخواست
    if (type === "register") {
      await User.findOneAndUpdate({ phoneNumber }, { isActive: true });
    } else if (type === "login") {
      // لاگین با OTP
      // می‌تونی JWT صادر کنی یا وضعیت لاگین رو ست کنی
    } else if (type === "reactivate") {
      // فعال‌سازی مجدد
      await User.findOneAndUpdate({ phoneNumber }, { isActive: true });
    } else {
      return new Response(
        JSON.stringify({ message: "نوع درخواست نامعتبر است" }),
        {
          status: 400,
        }
      );
    }

    await Otp.deleteOne({ _id: otp._id });

    return new Response(
      JSON.stringify({ message: "کد وارد شده صحیح می‌باشد" }),
      { status: 200 }
    );
  } catch (err) {
    console.error("Verify OTP Error:", err);
    return new Response(JSON.stringify({ message: "خطا در تایید کد" }), {
      status: 500,
    });
  }
}
