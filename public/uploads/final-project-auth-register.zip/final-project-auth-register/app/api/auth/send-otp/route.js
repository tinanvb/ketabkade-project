import sendOtp from "@/app/lib/sendOtp";

export async function POST(request) {
  const { phoneNumber, type } = await request.json();

  const result = await sendOtp(phoneNumber, type);

  return new Response(JSON.stringify({ message: result.message }), {
    status: result.success ? 200 : 500,
  });
}
