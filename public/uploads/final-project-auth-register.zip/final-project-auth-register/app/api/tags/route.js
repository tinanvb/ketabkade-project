import connectToDatabase from "@/app/lib/db";
import Tag from "@/models/Tag";

export async function GET(request) {
  await connectToDatabase();
  const tags = await Tag.find({});
  return new Response(JSON.stringify(tags), { status: 200 });
}

export async function POST(request) {
  await connectToDatabase();
  try {
    const body = await request.json();
    if (
      !body.name ||
      typeof body.name !== "string" ||
      body.name.trim() === ""
    ) {
      return new Response(
        JSON.stringify({ message: "نام برچسب الزامی میباشد" }),
        {
          status: 400,
        }
      );
    }
    if (body.name.length <= 3 || body.name.length >= 100) {
      return new Response(
        JSON.stringify({
          message: "نام برچسب باید بین ۳ تا ۱۰۰ کاراکتر باشد",
        }),
        {
          status: 400,
        }
      );
    }
    if (typeof body.isActive !== "boolean") {
      return new Response(
        JSON.stringify({
          message: " وضعیت باید true یا false باشد ",
        }),
        {
          status: 400,
        }
      );
    }
    const tag = await Tag.create(body);
    return new Response(JSON.stringify(tag), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ message: error.message }), {
      status: 500,
    });
  }
}
