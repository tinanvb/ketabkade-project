import OtpForm from "@/app/components/ui/auth/OtpForm";
import Link from "next/link";

const Otp = () => {

  return (
    <>
      <h1 className="title fw-bold"></h1>
      <OtpForm />
      <div className="otp-link">
        <Link href="/auth/otp">ورود با رمز یکبار مصرف</Link>
      </div>
    </>
  );
};

export default Otp;
